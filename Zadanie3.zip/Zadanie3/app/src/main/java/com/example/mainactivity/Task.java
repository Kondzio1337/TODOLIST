package com.example.mainactivity;

import java.util.Date;
import java.util.List;
import java.util.UUID;

public class Task {
    private UUID id;
    private String name;
    private Date date;
    private boolean done;
    public Task(){
        id=UUID.randomUUID();
        date=new Date();
    }
    public void setName(String name1){
        name=name1;
    }

    public void setDone(boolean b) {
        done=b;
    }

    public Object getDate() {
        return date;
    }

    public boolean isDone() {
        return done;
    }

    public String getName() {
        return name;
    }

    public UUID getId() {
        return id;
    }

}
